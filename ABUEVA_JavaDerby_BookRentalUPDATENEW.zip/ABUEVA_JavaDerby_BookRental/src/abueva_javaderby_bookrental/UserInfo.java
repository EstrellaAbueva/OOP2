/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abueva_javaderby_bookrental;

import java.util.Date;

/**
 *
 * @author PC
 */
public class UserInfo {
    private String libraryID;
    private String firstname;
    private String middlename;
    private String lastname;
    private int age;
    private String day;
    private String validID;
    private String username;
    private String password;
    
    public UserInfo(){}

    public UserInfo(String libraryID, String firstname, String middlename, String lastname, int age, String day, String validID, String username, String password) {
        this.libraryID = libraryID;
        this.firstname = firstname;
        this.middlename = middlename;
        this.lastname = lastname;
        this.age = age;
        this.day = day;
        this.validID = validID;
        this.username = username;
        this.password = password;
    }

    public UserInfo(String firstname, String middlename, String lastname, int age, String day, String validID, String username, String password) {
        this.firstname = firstname;
        this.middlename = middlename;
        this.lastname = lastname;
        this.age = age;
        this.day = day;
        this.validID = validID;
        this.username = username;
        this.password = password;
    }
    
    
    public String getLibraryID() {
        return libraryID;
    }

    public void setLibraryID(String libraryID) {
        this.libraryID = libraryID;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getValidID() {
        return validID;
    }

    public void setValidID(String validID) {
        this.validID = validID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    
}
