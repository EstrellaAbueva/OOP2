/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellooop2f1;

/**
 *
 * @author PC
 */
public class Circle implements InterfaceCircle, InterfaceSample{
    public <T> void display(T t){
        System.out.println(t);
    }
    
    public double getCircumference(){
        System.out.println(max);
        return 0;
    }
    
    public double getArea(){
         return 0;
    }
    
    public static < E > void printArray( E[] inputArray ) {
      // Display array elements
      for(E element : inputArray) {
         System.out.printf("%s ", element);
      }
      System.out.println();
   }
}
