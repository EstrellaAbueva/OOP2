/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface.generic.and.collection.pkgclass.activity;
import java.util.*;
/**
 *
 * @author PC
 */
public class GenericClass <T>{
    private T t;
    
    //constructors

    public GenericClass() {}

    public GenericClass(T t) {
        this.t = t;
    }
    
    //getters and setter

    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }
    
    public static < T extends Comparable> void selectionSort( T[] inputArray ){
        for(int i = 0; i < inputArray.length - 1; i++){
            int min = i;
            for(int j = i + 1; j < inputArray.length; j++){
                if(inputArray[j].compareTo(inputArray[min]) < 0){
                    min = j;
                }
            }
            if(min != i){
                T tempo = inputArray[i];
                inputArray[i] = inputArray[min];
                inputArray[min] = tempo;
            }
        }
    }
    
    public static < E > void printArray( E[] inputArray ) {
      // Display array elements
      System.out.println("Array contains: ");
      for(E element : inputArray) {
         System.out.printf("%s ", element);
      }
      System.out.println();
    }

    public static < T extends Comparable> boolean isEqualTo(T[] inputArray, T[] inputArray1){ 
        selectionSort(inputArray);
        selectionSort(inputArray1);
        
        return Arrays.equals(inputArray, inputArray1);
    }
    
}
