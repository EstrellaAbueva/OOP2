/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellooop2f1;

/**
 *
 * @author PC
 */
public class Student extends Person {
    private String course;
    private int year;
    
    public Student(){}
    
    public Student(String course, int year) {
        this.course = course;
        this.year = year;
    }

    public Student(String course, int year, String name, int age) {
        super(name, age);
        this.course = course;
        this.year = year;
    }
    
    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    
    public boolean equals(Object o){
        if(o instanceof Student){
            Student temp = (Student) o;
            if(super.equals(temp) && this.getCourse().equals(temp.getCourse()) == true && this.getYear() == temp.getYear()){
                return true;
            }
        }
        return false;
    }
    
    public String toString() {
        return super.toString() + "Course: " + course + "\nYear: " + year + "\n";
    }
    
   
   
    public void display(){} 
    
}
