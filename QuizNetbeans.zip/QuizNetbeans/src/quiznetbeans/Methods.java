/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiznetbeans;

/**
 *
 * @author PC
 */
public class Methods {
    private String type;
    private int days;
    private double disc;

    public Methods() {}

    public Methods(String type, int days, double discount) {
        this.type = type;
        this.days = days;
        this.disc = discount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public double getDisc() {
        return disc;
    }

    public void setDisc(double disc) {
        this.disc = disc;
    }
    
    public double computeFee(){
        double answer = 0;
        if("Single".equals(getType())){
            answer = 500 * getDays() - getDiscount();
        }else if ("Double".equals(getType())){
            answer = 1000 * getDays() - getDiscount();
        }else if("Superior".equals(getType())){
            answer = 1500 * getDays() - getDiscount();
        }else{
            answer = 0;
        }
        
        return answer;
    }
    
    public double getDiscount(){
        double discount = 0;
       if("Single".equals(getType())){
            discount = 500 * getDays() * getDisc()/100;
        }else if ("Double".equals(getType())){
            discount = 1000 * getDays() * getDisc()/100;
        }else if("Superior".equals(getType())){
            discount = 1500 * getDays() * getDisc()/100;
        }else{
            discount = 0;
        }
       return discount;
    }
}
