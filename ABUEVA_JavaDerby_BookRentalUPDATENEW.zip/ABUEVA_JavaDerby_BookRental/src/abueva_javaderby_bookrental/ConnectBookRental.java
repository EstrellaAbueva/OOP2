/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abueva_javaderby_bookrental;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author PC
 */
public class ConnectBookRental {
    Connection conn;
    
    public ConnectBookRental(){
        try{
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/BookRental", "administrator", "12345");
        }catch(SQLException e){
            System.out.println(e.toString());
        }
    }
    
    public boolean addNewUser(UserInfo cust){
        Statement stmt;
        String sql;
        int libID = 1001;
        ResultSet rs = null;
        
        try{
            sql  =  "select libraryid from useinfo order by libraryid desc";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next() == false){
                libID = 1001;
            }else{
                libID = rs.getInt(1) + 1;
            }
            
            sql = "insert into useinfo values ('" + Integer.toString(libID) + "','" + cust.getFirstname() +"','" + cust.getMiddlename() + "','" + cust.getLastname() + "', " + cust.getAge() + ", '" + cust.getDay() + "','" + cust.getValidID() + "','" + cust.getUsername() + "','" + cust.getPassword()+ "')";
            
            stmt = conn.createStatement();
            stmt.execute(sql);
                
        
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        return true;
    }
    
    public boolean checkUname(String username){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from useinfo where username='" + username+"'";
        try{
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public boolean checkLibraryID(String libraryID){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from useinfo where libraryID='" + libraryID +"'";
        try{
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
     public boolean checkPass(String password){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from useinfo where password = '" + password+ "'";
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
 
    public UserInfo login(String uname, String pass){
        Statement  stmt;
        String sql = "select * from useinfo where username='" + uname + "' and password='"+ pass +"'";
        ResultSet rs = null;
        UserInfo u = null;
        
        try{
             stmt = conn.createStatement();
             rs = stmt.executeQuery(sql);
             
             if(rs.next()){
                  u = new UserInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
                  return u;
             }
         }catch(SQLException e){
            System.out.println(e.toString());
         }
         return u;
    }
     
    public ArrayList displayAllBooks(){
        ArrayList<BookCatalogue> bc = new ArrayList<>();
        Statement stmt;
        String sql = "select * from bookcatalogue";
        ResultSet rs = null;
        
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                while(rs.next()){
                    BookCatalogue b = new BookCatalogue(rs.getString(1),rs.getString(2),rs.getString(3));
                    bc.add(b);
                }
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bc;
    }
    
    public ArrayList displayAvail(){
        ArrayList<BookAvailability> bc = new ArrayList<>();
        Statement stmt;
        String sql = "select * from bookavailability";
        ResultSet rs = null;
        
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                while(rs.next()){
                    BookAvailability b = new BookAvailability(rs.getString(1), rs.getString(2), rs.getBoolean(3), rs.getString(4), rs.getString(5), rs.getDouble(6));
                    bc.add(b);
                }
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bc;
    }
     
    public void borrowBook(UserInfo i, int selected, ArrayList<BookAvailability> book){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); // Using today's date
        String reqDate = sdf.format(c.getTime());
        c.add(Calendar.DATE, 5); // Adding 5 days
        String retDate = sdf.format(c.getTime());

        if(book.get(selected).isAvailability() == true){
            Statement stmt;
            String sql = "update bookavailability set availability=" + false + " ,libraryid='" + 123456 + "', requestdate='" + reqDate + "', returndate='" + retDate + "' where bookid='" + book.get(selected).getBookID() + "'";
            System.out.println(book.get(selected).getBookID());
            
            try{
                stmt = conn.createStatement();
                stmt.executeUpdate(sql);
            }catch(SQLException e){
                System.out.println(e.toString());
            }
        }
    }
    
    
}