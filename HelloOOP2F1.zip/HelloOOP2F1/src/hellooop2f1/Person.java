/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellooop2f1;

/**
 *
 * @author PC
 */
public abstract class Person {
    private String name;
    private int age;
    
    public Person () {}
    
    public Person(String name, int age){
        this.name = name;
        this.age = age;
    }
    //setters
    public void setName(String name){
        this.name = name;
    }
    
    public void setAge(int age){
        this.age = age;
    }
    //getters
    public String getName(){
        return name;
    }
    
    public int getAge(){
        return age;
    }
    
    public String toString(){
        return "Name: " + getName() + "\nAge: " + getAge() + "\n";
    }
    
    public boolean equals(Object o){
        if(o instanceof Person){
            Person temp = (Person) o;
            if(this.getName().equals(temp.getName()) == true && this.getAge() == temp.getAge())
                return true;
        }    
        return false;
    }
    
    public abstract void display();
}
