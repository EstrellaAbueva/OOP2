/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databasederby;

import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 *
 * @author PC
 */
public class Connect {
    
    Connection conn;
    public Connect(){
        try{
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/BankApp", "administrator", "qwerty");
        }catch(SQLException e){
            System.out.println(e.toString());
        }
    }
    //insert into customer values('223','linc','cruz','paz','user1','qwert098',500);
    public boolean addNewCustomer(Customer cust){
        Statement stmt;
        String sql;
        sql =   "insert into customer values ('" + cust.getAccountNumber()+"','"+ cust.getFirstname()+"','"+ cust.getMiddlename()+"','"+ cust.getLastname()+"','"+ cust.getUsername()+"','"+ cust.getPassword()+"',"+ cust.getBalance() + ")";
        try{
            if(checkUsername(cust.getUsername()) == false && checkAccountNumber(cust.getAccountNumber()) == false){
                stmt = conn.createStatement();
                stmt.execute(sql);
                return true;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        return true;
        
    }
    
    public boolean checkUsername(String username){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from customer where username='" + username+ "'";
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
     public boolean checkPassword(String password){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from customer where password='" + password+ "'";
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
     
    public boolean checkAccountNumber(String accountNumber){
        Statement stmt;
        String sql;
        ResultSet rs=null;
        
        sql = "select * from customer where accountnumber='" + accountNumber+"'";
        try{
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public ArrayList displayAll(){
        ArrayList <Customer> customs = new ArrayList <>();
        Statement stmt;
        String sql = "select * from customer";
        ResultSet rs = null;
       
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                while(rs.next()){
                    Customer c = new Customer(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getDouble(7));
                    customs.add(c);
                }
                return customs;
            }
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return customs;
    }
    
    public boolean updateCustomer (Customer c){
        String sql = "update customer set firstname = '" + c.getFirstname() + "', middlename = '" + c.getMiddlename() + "', lastname = '" + c.getLastname() + "', balance = " + c.getBalance() +
                " where accountnumber = '" + c.getAccountNumber() + "'";
        Statement stmt;
        
        try{
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public boolean deleteCustomer (Customer c){
        String sql = "delete from customer where accountnumber = '" + c.getAccountNumber() + "'";
        Statement stmt;
        
        try{
            stmt = conn.createStatement();
            stmt.execute(sql);
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    
    public boolean UpdatePassword(String password, String username){
        String sql =  "update customer set password = '" + password + "' where username = '" + username + "'";
        Statement stmt;
        
        try{
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public double displayBalance(String user){
        double bal = 0;
        Statement stmt;
        String sql = "select * from customer where username = '" + user + "'";
        ResultSet rs = null;
       
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                bal = rs.getDouble(7);
                return bal;
            }
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bal;
    } 
}
