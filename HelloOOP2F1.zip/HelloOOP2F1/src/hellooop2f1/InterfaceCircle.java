/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hellooop2f1;

/**
 *
 * @author PC
 */
public interface InterfaceCircle {
    int max = 10;
    //public void display();
    public double getCircumference();
    public double getArea();
}
