/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface.generic.and.collection.pkgclass.activity_1;
import java.util.*;
/**
 *
 * @author PC
 */
public class CollectionBooks {
    private ArrayList <Book> blist;
    
    public CollectionBooks() {
        blist = new ArrayList <> (100);
    }
    
    public CollectionBooks(ArrayList <Book> blist) {
        this.blist = blist;
    }
    
    public ArrayList <Book> getBlist() {
        return blist;
    }

    public void setBlist(ArrayList <Book> blist) {
        this.blist = blist;
    }

    public void add(Book b){
       blist.add(b);
    }
    
    public void printAll(){
        Iterator itr1 = blist.iterator(); 
        int ctr = 0;
        System.out.println("\nBook\\s in the list: ");
        for (Book temp : blist) {
            temp.display(); 
            System.out.println("\n");
        }
    }
    
    public int count(){
        return blist.size();
    }
    
    public Book search(Object e){//sige null ang return
        Book search = null;
        
        Iterator itr1 = blist.iterator();  
        for (Book temp : blist){
           if(temp.equals(e)){
               System.out.println("BOOK FOUND!\nSearched Book: ");
               temp.display();
               return temp;
           }   
        }
        System.out.println("ERROR FINDONG BOOK!");
        return search;
    }
            
    public void remove(int index){
        blist.remove(index);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scan = new Scanner(System.in);
        
        String publisher, title;
        int yearPublished;
        float price;
   
        CollectionBooks colbooks = new CollectionBooks();
        
        int number, numberOfVolumes, choose;
        String characterName;
        do{
            System.out.println("\nMAIN MENU");
            System.out.println("[1]Add");
            System.out.println("[2]Count");
            System.out.println("[3]Print");
            System.out.println("[4]Search");
            System.out.println("[5]Delete");
            System.out.println("[6]Exit");
            
            System.out.print("\nYour Choice: ");
            number = scan.nextInt();
       
            switch(number){
                case 1://add
                    scan.nextLine();
                    System.out.print("Enter Publisher\t\t\t:\t ");
                    publisher = scan.nextLine();
                     
                    System.out.print("Enter Year Published\t\t:\t ");
                    yearPublished = scan.nextInt();

                    System.out.print("Price\t\t\t\t:\t P ");
                    price = scan.nextFloat();
                    scan.nextLine();
                    System.out.print("Title\t\t\t\t:\t ");
                    title = scan.nextLine();
                    
                    System.out.println("\n1 : Cartoon Book");
                    System.out.println("2 : Encyclopedia Book");
                    System.out.print("What type of Book? [Cartoon or Encyclopedia] Choose 1 only : ");
                    choose = scan.nextInt();
                    if(choose == 1){
                        scan.nextLine();
                        System.out.print("Enter Character Name\t\t:\t ");
                        characterName = scan.nextLine();
                        CartoonBook cart = new CartoonBook(characterName, publisher, yearPublished, price, title);
                        cart.compute();
                        colbooks.add(cart);
                    }else {
                        System.out.print("Enter Number of Volumes\t\t:\t ");
                        numberOfVolumes = scan.nextInt();
                        EncyclopediaBook cart = new EncyclopediaBook(numberOfVolumes, publisher, yearPublished, price, title);
                        cart.compute();
                        colbooks.add(cart);
                    }
                    break;
                case 2://count
                    int counts = colbooks.count();
                    System.out.println("Count\t\t\t\t:\t " + counts);
                    break;
                case 3://print
                    colbooks.printAll();
                    break;
                case 4://search3
                    scan.nextLine();
                    System.out.print("Enter Publisher\t\t\t:\t ");
                    publisher = scan.nextLine();
                     
                    System.out.print("Enter Year Published\t\t:\t ");
                    yearPublished = scan.nextInt();

                    System.out.print("Price\t\t\t\t:\tP ");
                    price = scan.nextFloat();
                    scan.nextLine();
                    System.out.print("Title\t\t\t\t:\t");
                    title = scan.nextLine();
                    
                    System.out.println("\n1 : Cartoon Book");
                    System.out.println("2 : Encyclopedia Book");
                    System.out.print("What book to Search\t:\t\t ");
                    choose = scan.nextInt();
                    
                    if(choose == 1){
                        scan.nextLine();
                        System.out.print("Enter Character Name\t\t:\t ");
                        characterName = scan.nextLine();
                        System.out.println("\n");
                        CartoonBook cart = new CartoonBook(characterName, publisher, yearPublished, price, title);
                        Book ret = colbooks.search(cart);
                        System.out.println(ret);
                    }else {
                        System.out.print("Enter Number of Volumes\t\t:\t ");
                        numberOfVolumes = scan.nextInt();
                        System.out.println("\n");
                        EncyclopediaBook cart = new EncyclopediaBook(numberOfVolumes, publisher, yearPublished, price, title);
                        Book ret = colbooks.search(cart);
                        System.out.println(ret);
                    }
                    break;
                case 5://delete
                    scan.nextLine();
                    System.out.print("What book to Delete in the List\t:\t ");
                    choose = scan.nextInt();
                    colbooks.remove(choose);
                    break;
                case 6://exit
                    break;
                default:
                    break;
            }
            
        }while(number != 6);
    }
}
