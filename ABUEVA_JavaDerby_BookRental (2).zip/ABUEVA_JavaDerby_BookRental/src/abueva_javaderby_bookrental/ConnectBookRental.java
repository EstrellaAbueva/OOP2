/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abueva_javaderby_bookrental;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author PC
 */
public class ConnectBookRental {
    Connection conn;
    
    public ConnectBookRental(){
        try{
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/BookRental", "administrator", "12345");
        }catch(SQLException e){
            System.out.println(e.toString());
        }
    }
    //meh 1
    public boolean addNewUser(UserInfo cust){
        Statement stmt;
        String sql;
        int libID = 1001;
        ResultSet rs = null;
        
        try{
            sql  =  "select libraryid from useinfo order by libraryid desc";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next() == false){
                libID = 1001;
            }else{
                libID = rs.getInt(1) + 1;
            }
            
            sql = "insert into useinfo values ('" + Integer.toString(libID) + "','" + cust.getFirstname() +"','" + cust.getMiddlename() + "','" + cust.getLastname() + "', " + cust.getAge() + ", '" + cust.getDay() + "','" + cust.getValidID() + "','" + cust.getUsername() + "','" + cust.getPassword()+ "')";
            System.out.println(sql);
            stmt = conn.createStatement();
            stmt.execute(sql);
                
        
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        return true;
    }
    
    public boolean loginAdmin(UserInfo admin){
        Statement  stmt;
        String sql = null;
        ResultSet rs = null;
        
        try{
            if (admin.getUsername().equals("admin") && admin.getPassword().equals("123456"))
                sql = "select * from useinfo where username='" + admin.getUsername() + "' and password='"+ admin.getPassword() +"'";
               
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            return rs.next();
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
   
    public boolean checkUname(String username){
        String sql;
        Statement stmt;
        ResultSet rs = null;
        UserInfo u = null;
        
        try{
            sql = "select * from useinfo where username='" + username + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next())
                return true;
           
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    //meh 2
    public boolean checkLibraryID(String libraryID){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from useinfo where libraryID='" + libraryID +"'";
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    //meh
    public boolean chechBookID(String bookid){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        sql = "select * from useinfo where bookid ='" + bookid +"'";
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                return true;
            }else{
                return false;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    //meh
    public boolean checkPass(String password){
        String sql;
        Statement stmt;
        ResultSet rs = null;
        UserInfo u = null;
        
        try{
            sql = "select * from useinfo where password='" + password + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next())
                return true;
           
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public boolean checkBook(String bookid){
        String sql;
        Statement stmt;
        ResultSet rs = null;
        
        try{
            sql = "select * from bookcatalogue where bookid = '" + bookid + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next())
                return true;
           
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    //meh 3
    public UserInfo login(String uname, String pass){
        Statement  stmt;
        String sql = "select * from useinfo where username='" + uname + "' and password='"+ pass +"'";
        ResultSet rs = null;
        UserInfo u = null;
        
        try{
             stmt = conn.createStatement();
             rs = stmt.executeQuery(sql);
             
             if(rs.next()){
                  u = new UserInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
                  return u;
             }
         }catch(SQLException e){
            System.out.println(e.toString());
         }
         return u;
    }
     
    public ArrayList displayAllBooks(){
        ArrayList<BookCatalogue> bc = new ArrayList<>();
        Statement stmt;
        String sql = "select * from bookcatalogue";
        ResultSet rs = null;
        
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
           
                while(rs.next()){
                    BookCatalogue b = new BookCatalogue(rs.getString(1),rs.getString(2),rs.getString(3));
                    bc.add(b);
                }
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bc;
    }
    
    public ArrayList displayAllReceipts(){
        ArrayList<BookReceipt> bc = new ArrayList<>();
        Statement stmt;
        String sql = "select * from bookreceipt";
        ResultSet rs = null;
        
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
           
                while(rs.next()){
                    BookReceipt b = new BookReceipt(rs.getString(1),rs.getString(2),rs.getString(3), rs.getString(4));
                    bc.add(b);
                }
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bc;
    }
    
    public ArrayList displayAvail(){
        ArrayList<BookAvailability> bc = new ArrayList<>();
        Statement stmt;
        String sql = "select * from bookavailability";
        ResultSet rs = null;
        
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            
                while(rs.next()){
                    BookAvailability b = new BookAvailability(rs.getString(1), rs.getString(2), rs.getBoolean(3), rs.getString(4), rs.getString(5), rs.getDouble(6));
                    bc.add(b);
                }
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bc;
    }
    
    //meh 4
    public ArrayList displayUserInfo(){
        ArrayList<UserInfo> bc = new ArrayList<>();
        Statement stmt;
        String sql = "select * from useinfo";
        ResultSet rs = null;
        
        try{
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            
                while(rs.next()){
                    UserInfo b = new UserInfo(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
                    bc.add(b);
                }
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return bc;
    }
    
    //meh 5
    public boolean adminAddUser(UserInfo user){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        try{
            sql = "insert into useinfo values ('" + user.getLibraryID() + "','" + user.getFirstname() +"','" + user.getMiddlename() + "','" + user.getLastname() + "', " + user.getAge() + ", '" + user.getDay()+ "','" + user.getValidID() + "','" + user.getUsername() + "','" + user.getPassword()+ "')";
            if(checkLibraryID(user.getLibraryID()) == false){
                stmt = conn.createStatement();
                stmt.execute(sql);
                return true;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    //meh 6
    public boolean updateUserData(UserInfo c){
        String sql = "";
        System.out.println(sql);
        Statement stmt;
        
        try{
            sql = "update useinfo set firstname = '" + c.getFirstname() + "', middlename = '" + c.getMiddlename() + "', lastname = '" + c.getLastname() + "', age = " + c.getAge() + ", birthday = '" + c.getDay() +
                "', validid = '" + c.getValidID() + "', username = '" + c.getUsername() + "', password = '" + c.getPassword() + "' where libraryid = '" + c.getLibraryID() + "'";
            System.out.println(sql);
            
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    //meh 7
    public boolean deleteUserData(UserInfo c){
        String sql = "delete from useinfo where libraryid = '" + c.getLibraryID()+ "'"; 
        System.out.println(sql);
        Statement stmt;
        
        try{
            stmt = conn.createStatement();
            stmt.execute(sql);
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public boolean addNewBook(BookCatalogue bc){
        Statement stmt;
        String sql = "insert into bookcatalogue values('" + bc.getBookID() +"','" + bc.getBookTitle() + "','" + bc.getAuthor() + "')";;
        
        try{
            if(checkBook(bc.getBookID()) == false){
                stmt = conn.createStatement();
                stmt.execute(sql);
                
                sql = "insert into bookavailability values('" + bc.getBookID() + "',null,true,null,null," + 0 + ")";
                stmt = conn.createStatement();
                stmt.execute(sql);
            
                return true;
            }    
            
        }catch(SQLException e){
            System.out.println(e.toString());
            return false;
        }
        return true;
    }
    
    public boolean updateBook(BookCatalogue bc){
        String sql = "";
        System.out.println(sql);
        Statement stmt;
        
        try{
            sql =  "update bookcatalogue set booktitle = '" + bc.getBookTitle() +"'," + "author ='" + bc.getAuthor() + "' where bookid = '"+ bc.getBookID() + "'";
            System.out.println(sql);
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            
            return true;
            
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public boolean deleteBook(BookCatalogue bc){
        String sql = "delete from bookcatalogue where bookid = '" + bc.getBookID()+ "'";
        System.out.println(sql);
        Statement stmt;
        
        try{
            stmt = conn.createStatement();
            stmt.execute(sql);
            
            sql = "delete from bookavailability where bookid = '" + bc.getBookID()+ "'";
            stmt = conn.createStatement();
            stmt.execute(sql);
            return true;
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public void borrow(int selected, ArrayList<BookAvailability> book, UserInfo user){
        Integer transactionID;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); // Using today's date
        String reqDate = sdf.format(c.getTime());
        c.add(Calendar.DATE, 5); // Adding 5 days
        String retDate = sdf.format(c.getTime());
        
        ResultSet rs = null;
        Statement stmt;
        String sql;
        if(book.get(selected).isAvailability() == true){
            
            System.out.println(book.get(selected).getBookID());
            
            try{
                sql = "update bookavailability set availability=" + false + " ,libraryid='" + user.getLibraryID() + "', requestdate='" + reqDate + "', returndate='" + retDate + "' where bookid='" + book.get(selected).getBookID() + "'";
                stmt = conn.createStatement();
                stmt.executeUpdate(sql);
                
                sql = "select transactionid from bookreceipt order by transactionid desc";
                stmt = conn.createStatement();
                rs = stmt.executeQuery(sql);
            
            if(rs.next() == false){
                transactionID = 100001;
            }else{
                transactionID = rs.getInt(1) + 1;
            }
                
                sql = "insert into bookreceipt values('" + transactionID + "','" + book.get(selected).getBookID() + "','" + user.getLibraryID() + "','borrow')";
                stmt = conn.createStatement();
                stmt.execute(sql);
                
            }catch(SQLException e){
                System.out.println(e.toString());
            }
        }
    }
    
    public boolean renew(BookCatalogue chosen, UserInfo user){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        try{
            sql = "select * from bookavailability where bookid= '" + chosen.getBookID() + "' and libraryid='" + user.getLibraryID() + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            System.out.println(sql);
            
            
            if(rs.next() && rs.getDouble(6) == 0){
                System.out.println(sql);
                return true;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
      public void renewbook(BookAvailability avail, UserInfo user){
        int transactionID;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); // Using today's date
        String reqDate = sdf.format(c.getTime());
        System.out.println(reqDate);
        c.add(Calendar.DATE, 5); // Adding 5 days
        String retDate = sdf.format(c.getTime());
        System.out.println(retDate);
        System.out.println(c);
        
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        avail.setRequestDate(reqDate);
        avail.setReturnDate(retDate);
        
        try{
            sql = "update bookavailability set requestdate='" + reqDate + "', returndate='" + retDate + "' where bookid='" + avail.getBookID() + "'";
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            
            sql = "select transactionid from bookreceipt order by transactionid desc";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next() == false){
                transactionID = 100001;
            }else{
                transactionID = rs.getInt(1) + 1;
            }
                
                sql = "insert into bookreceipt values('" + transactionID + "','" + avail.getBookID() + "','" + user.getLibraryID() + "','renew')";
                stmt = conn.createStatement();
                stmt.execute(sql);
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        
    }
     
    public double returnBook(BookAvailability avail, BookCatalogue chosenbook, ArrayList<BookAvailability> book, UserInfo user){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        try{
            sql = "select * from bookavailability where bookid='" + chosenbook.getBookID()+ "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            System.out.println(chosenbook.getBookID());
            System.out.println(sql);
            System.out.println(avail.getReturnDate());
            
            
            rs.next();
            double fine = rs.getDouble(6);
            sql = "select transactionid from bookreceipt order by transactionid desc";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            int transactionID;
            
            if(rs.next() == false){
                transactionID = 100001;
            }else{
                transactionID = rs.getInt(1) + 1;
            }
            
            sql = "update bookavailability set libraryid=null, returndate=null, requestdate=null, availability=true, fine = 0 " + "where bookid='" + chosenbook.getBookID() + "' and libraryid='" + user.getLibraryID() + "'";
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
                
            sql = "insert into bookreceipt values('" + transactionID + "','" + avail.getBookID() + "','" + user.getLibraryID() + "','return')";
            stmt = conn.createStatement();
            stmt.execute(sql);
            
            return fine;
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return 0;
    }
    
    public boolean returnCheck(BookCatalogue chosenbook, ArrayList<BookAvailability> book, UserInfo user){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        try{
            sql = "select * from bookavailability where bookid= '" + chosenbook.getBookID() + "' and libraryid='" + user.getLibraryID() + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            if(rs.next()){
                System.out.println(sql);
                return true;
            }
        }catch(SQLException e){
            System.out.println(e.toString());
        }
        return false;
    }
    
    public void updateFine(ArrayList<BookAvailability> bookAvail_list){
        Statement stmt;
        String sql;
        ResultSet rs = null;
        
        for(BookAvailability book: bookAvail_list){
            if(book.isAvailability() == false){
                try{
                    sql = "select * from bookavailability where bookid='" + book.getBookID()+ "'";
                    stmt = conn.createStatement();
                    rs = stmt.executeQuery(sql);
                    System.out.println(sql);

                    rs.next();
                    Date due = rs.getDate(5);
                    Calendar dueDate = Calendar.getInstance();
                    dueDate.setTime(due);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Calendar today = Calendar.getInstance();
                    today.setTime(new Date()); // Using today's date
                    int ctr = 0;
                    String bookD = sdf.format(dueDate.getTime());
                    
                    if(dueDate.compareTo(today) < 0){
                    while(dueDate.compareTo(today) != 1){
                        dueDate.add(Calendar.DATE, 1);
                        bookD = sdf.format(today.getTime());
                        System.out.println(bookD);
                        ctr++;
                        System.out.println(dueDate.compareTo(today));
                        System.out.println(ctr);
                    }
                    
                    double fine = 20 * (ctr);
            System.out.println(fine);
            sql = "update bookavailability set fine=" + fine + " where bookid= '" + book.getBookID() + "'";
            stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            System.out.println(sql);
                }


                } catch(SQLException e){
                    System.out.println(e.toString());
                }
            }
        }
    }
    
}