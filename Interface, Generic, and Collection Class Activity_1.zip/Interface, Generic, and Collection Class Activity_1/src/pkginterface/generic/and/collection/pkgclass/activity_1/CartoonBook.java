/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkginterface.generic.and.collection.pkgclass.activity_1;

/**
 *
 * @author PC
 */
public class CartoonBook extends Book{
    private String characterName;
    
    //constructors
    public CartoonBook() {}

    public CartoonBook(String characterName) {
        this.characterName = characterName;
    }

    public CartoonBook(String characterName, String publisher, int yearPublished, float price, String title) {
        super(publisher, yearPublished, price, title);
        this.characterName = characterName;
    }

    //setters and getters
    public String getCharacterName() {
        return characterName;
    }

    public void setCharacterName(String characterName) {
        this.characterName = characterName;
    }
    
    public void display(){
        super.display();
        System.out.println("Character Name\t:\t" + getCharacterName());
    }
    
    public void compute(){
        float newPrice = (float)(super.getPrice() * 0.3);
        super.setPrice(newPrice);
    }
}
