/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abueva_javaderby_bookrental;

/**
 *
 * @author PC
 */
public class BookReceipt {
    private String transId;
    private String bookid2;
    private String libId;
    private String transmade;

    public BookReceipt() {}

    public BookReceipt(String transId, String bookid2, String libId, String transmade) {
        this.transId = transId;
        this.bookid2 = bookid2;
        this.libId = libId;
        this.transmade = transmade;
    }

    public String getTransId() {
        return transId;
    }

    public String getBookid2() {
        return bookid2;
    }

    public String getLibId() {
        return libId;
    }

    public String getTransmade() {
        return transmade;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public void setBookid2(String bookid2) {
        this.bookid2 = bookid2;
    }

    public void setLibId(String libId) {
        this.libId = libId;
    }

    public void setTransmade(String transmade) {
        this.transmade = transmade;
    }
    
}
