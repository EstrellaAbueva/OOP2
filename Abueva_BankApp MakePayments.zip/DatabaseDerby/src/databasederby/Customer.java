/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package databasederby;

/**
 *
 * @author PC
 */
public class Customer {
    private String accountNumber;
    private String firstname;
    private String middlename;
    private String lastname;
    private String username;
    private String password;
    private double balance;
    
    public Customer(){}

    public Customer(String password) {
        this.password = password;
    }
    
    public Customer(String accountNumber, String firstname, String middlename, String lastname, double balance) {
        this.accountNumber = accountNumber;
        this.firstname = firstname;
        this.middlename = middlename;
        this.lastname = lastname;
        this.balance = balance;
    }
     
    public Customer(String accountNumber, String firstname, String middlename, String lastname, String username, String password, double balance) {
        this.accountNumber = accountNumber;
        this.firstname = firstname;
        this.middlename = middlename;
        this.lastname = lastname;
        this.username = username;
        this.password = password;
        this.balance = balance;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getMiddlename() {
        return middlename;
    }

    public String getLastname() {
        return lastname;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    public String toString() {
        return  accountNumber + " " + firstname + " " + middlename + " " + lastname +  " " + balance;
    }
    
    
    
    
}
